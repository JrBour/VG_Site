<?php get_header(); ?>

<!--Partie 1 - SLOGAN-->
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div id="slogan">
				<h1 id="slogan1">Le corps accomplit</h1>
				<h2 id="slogan2">Ce que l'esprit croit</h2>
			</div>
		</div>

	</div>
</div>

<div class="partie_cours">
	<div class="col-md-12">
		<h1>Cours</h1>
	</div>
</div>

<div class="partie_sportif">
	<div class="row">
		<div class="col-lg-6 col-md-6" id="img_sportif"></div>
		<div class="col-lg-6 col-md-6" id="coaching_sportif">
			<h1 id="partie_sport">Coaching Sportif</h1>
			<p id="partie_sport">
				Martinus agens illas provincias pro praefectis aerumnas innocentium graviter gemens saepeque obsecrans
				ut ab omni culpa inmunibus parceretur, cum non inpetraret, minabatur se discessurum: ut saltem id metuens
				perquisitor malivolus tandem desineret quieti coalitos homines in aperta pericula proiectare.
			</p>
		</div>
	</div>
</div>
<div class="row">
	<div class="partie_sportif2">
		<div class="col-md-6" id="img_sportif2"></div>
		<div class="col-md-6" id="coaching_sportif2">
			<h1 id="partie_sport2">Coaching Sportif</h1>
			<p id="partie_sport2">
				Martinus agens illas provincias pro praefectis aerumnas innocentium graviter gemens saepeque obsecrans
				ut ab omni culpa inmunibus parceretur, cum non inpetraret, minabatur se discessurum: ut saltem id metuens
				perquisitor malivolus tandem desineret quieti coalitos homines in aperta pericula proiectare.
			</p>
		</div>
	</div>
</div>

<div class="partie_cours">
	<div class="row">
		<div class="col-md-12">
			<h1>Blog</h1>
		</div>
	</div>


<div class="row">
	<div class="col-md-6 col-md-offset-3" data-category="view">
		<div class="lib-panel">
			<div class="row box-shadow">
				<div class="col-md-6">
					<img class="lib-img-show" src="http://lorempixel.com/850/850/?random=123">
				</div>
				<div class="col-md-6">
					<div class="lib-row lib-header">
						Example library
						<div class="lib-header-seperator"></div>
					</div>
					<div class="lib-row lib-desc">
						Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor
					</div>
			</div>
		</div>
	</div>
</div>
	</div>
	</div>
<?php get_footer(); ?>
